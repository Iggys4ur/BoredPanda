import BoredPanda.*;

class Main {

  public static void main(String[] args) {

    boredPanda boPa = new boredPanda("Inigo");
    boPa.doPandaStuffForAPeriod();

  }
}