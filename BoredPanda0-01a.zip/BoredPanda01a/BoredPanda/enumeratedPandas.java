package BoredPanda;


public class enumeratedPandas {

    public enum Activity{

    }

    public enum Names{

    }

    public enum Quality{

    }

    public enum Luck {

    }
}
